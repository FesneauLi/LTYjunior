#include "print.h"
#include "sbi.h"

void puts(char *s) {
    // unimplemented
}

void puti(int x) {
    // unimplemented
}
